<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id12794768_admin","admin","id12794768_akademik") or die ("could not connect database");
?>